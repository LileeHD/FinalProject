package lilee.hd.jokesprovider;

public class JokesProvider {
    public String getJoke() {
        return "Why can't you hear Baptiste when he goes to the bathroom?\n" +
                "The \"p\" is silent.";
    }
}
