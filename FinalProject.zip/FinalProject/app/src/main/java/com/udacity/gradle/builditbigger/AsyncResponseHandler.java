package com.udacity.gradle.builditbigger;

public interface AsyncResponseHandler {
    void responseHandle(String output);
}
